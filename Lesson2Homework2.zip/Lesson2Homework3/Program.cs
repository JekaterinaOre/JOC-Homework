using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2Homework3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter Array length: ");

            int length;
            while (!int.TryParse(Console.ReadLine(), out length))
            {
                Console.Write("Your input is not a number!: ");
            }

            int[] myarray = new int[length];
            Console.WriteLine($"Please enter {length} elements in the array");
            for (int i = 0; i < myarray.Length; i++)
            {
                Console.Write($"element - {i} : ");
                while (!int.TryParse(Console.ReadLine(), out myarray[i]))
                {
                    Console.Write($"Please enter number for Array element {i}: ");
                }
            }
            Array.Sort(myarray);

            Console.WriteLine("\nArray elements in ascending order: ");

            foreach (int value in myarray)
            {
                Console.Write(value + " ");
            }
            Console.ReadKey();
        }
    }
}

