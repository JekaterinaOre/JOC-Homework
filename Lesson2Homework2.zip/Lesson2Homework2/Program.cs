using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2Homework2
{
    class Program
    {
        public static void Main()
        {
            
          
            int result = 0;

            Console.Write("Please enter number for the sum of the series 1 +11 + 111 + 1111 + ..");

            string input1 = Console.ReadLine();

            int result1 = 0;

            while (!int.TryParse(input1, out result1))
            {
                Console.WriteLine("Your input is not a number", input1);
                input1 = Console.ReadLine();
            }
            {
                Console.Write("Please enter the number of terms : ");
            string input2 = Console.ReadLine();
                int result2 = 0;


          while (!int.TryParse(input2, out result2))
                {
                    Console.WriteLine("Your input is not a number", input2);
                input2 = Console.ReadLine();
            }
            try
            {

                int i = Convert.ToInt32(input1);
                int n = Convert.ToInt32(input2);
                int t = 1;
                int sum = 0;

                for (i = 1; i <= n; i++)
            {
                Console.Write("{0} + ", t);
                sum = sum + t;
                t = (t * 10) + 1;
            }
            Console.WriteLine("\nThe Sum is : {0}\n", sum);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
                }
                Console.ReadKey();
        }
    }
    }
}