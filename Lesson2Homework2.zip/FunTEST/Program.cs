using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System;

class BiggestNumber
{
    static void Main()
    {

            Console.Write("Please enter the 1st number :");

        var num1 = int.Parse(Console.ReadLine());

        Console.Write("Please enter the 2nd number :");
        var num2 = int.Parse(Console.ReadLine());
        Console.Write("Please enter the 3rd number :");
        var num3 = int.Parse(Console.ReadLine());
         
                    if (num1 > num2 && num1 > num3)
        {
            Console.WriteLine("The biggest number is: {0}", num1);
        }
        else if (num2 > num1 && num2 > num3)
        {
            Console.WriteLine("The biggest number is: {0}", num2);
        }
        else
        {
            Console.WriteLine("The biggest number is: {0}", num3);
    
                Console.ReadKey();
                    //int a = int.Parse(input1); 
                }
            }
}
            
             

