using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2Homework1
{
    class Program
    {
        static void Main(string[] args)
          
        {

            Console.Write("Please enter the 1st number :");
            string input1  = Console.ReadLine();

            int result = 0;
         

            while (!int.TryParse(input1, out result))
            {
                Console.WriteLine("Please enter valid number", input1);
                input1 = Console.ReadLine();
            }
            Console.Write("Please enter the 2nd number :");
            string input2 = Console.ReadLine();

            int result2 = 0;
           

            while (!int.TryParse(input2, out result2))
            {
                Console.WriteLine("Please enter valid number", input2);
                input2 = Console.ReadLine();

            }
            Console.Write("Please enter the 3rd number :");
                string input3 = Console.ReadLine();
            
                int result3 = 0;

                while (!int.TryParse(input3, out result3))
                {
                    Console.WriteLine("Please enter valid number", input3);
                    input3 = Console.ReadLine();
            }
        
            try
                {

                int number1 = Convert.ToInt32(input1);
                int number2 = Convert.ToInt32(input2);
                int number3 = Convert.ToInt32(input3);


                if (number1 > number2)
            
                if (number1 > number3)
                {
                    Console.Write("The 1st Number is the greatest among three. \n\n");
                }
                else
                {
                    Console.Write("The 3rd Number is the greatest among three. \n\n");
                }
            
            else if (number2 > number3)
                Console.Write("The 2nd Number is the greatest among three \n\n");
            else
                Console.Write("The 3rd Number is the greatest among three \n\n");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
            }

            Console.ReadKey();
        }
    }
}